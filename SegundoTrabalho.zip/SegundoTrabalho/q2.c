/* serial_mat_mult.c -- Multiplica duas matrizes quadradas
 *
 * Entrada:
 *     n: Ordem das matrizes
 *     A,B: Matrizes de entrada
 * SaÃ­da:
 *     C: Matriz produto
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "timer.h"
#include <mpi.h>

#define MAX_ORDER 10

typedef float MATRIX_T[MAX_ORDER][MAX_ORDER];

int ** createMatrix(int N);
void Read_matrix(char* prompt, MATRIX_T A, int n);
void Serial_matrix_mult(MATRIX_T A, MATRIX_T B, MATRIX_T C, int n);
void Print_matrix(char* title, MATRIX_T C, int n);

int main(int argc, char **argv) {
    int
        i, j, n,
        **msend, **mreceive, tam, move,
        my_rank, p;

    MPI_Datatype column;

    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);

    MPI_Comm_size(MPI_COMM_WORLD, &p);

    if (my_rank == 0) {
        printf("Qual a ordem das matrizes?\n");
        scanf("%d", &n);
    }

    printf("%d\n", my_rank);

    MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);

    MPI_Type_vector(n, 1, n, MPI_INT, &column);
    MPI_Type_commit(&column);

    if (!my_rank) {
        msend = createMatrix(n);
    }


    mreceive = (int **) malloc(sizeof(int*) * n);
    for (i = 0; i < n; i++) {
        mreceive[i] = (int *) malloc(sizeof(int) * n / p);
        for (j = 0; j < n / p; j++) {
            mreceive[i][j] = 0;
        }
    }

    MPI_Scatter(msend, n / p, column, mreceive, n / p, column, 0, MPI_COMM_WORLD);

    if (my_rank == 1) {
        for (i = 0; i < n; i++) {

            for (j = 0; j < n / p; j++) {
                printf("%d ", mreceive[i][j]);
            }
            printf("\n");
        }
    }
    //Read_matrix("Entre A", A, n);
    //Print_matrix("A = ", A, n);
    //Read_matrix("Entre B", B, n);
    //Print_matrix("B = ", B, n);
    //Serial_matrix_mult(A, B, C, n);
    //Print_matrix("O produto Ã©", C, n);

    MPI_Type_free(&column);

    MPI_Finalize();

    return 0;
}  /* main */

int ** createMatrix(int N) {
    int i, j, **matrix;
    matrix = (int **) malloc(sizeof(int*) * N);
    srand(time(NULL));
    for (i = 0; i < N; i++) {
        *(matrix + i) = (int *) malloc(sizeof(int) * N);
        for (j = 0; j < N; j++) {
            *(*(matrix + i) + j) = rand() % 1000;
        }
    }
    return matrix;
}

/*****************************************************************/
void Read_matrix(
         char*     prompt  /* in  */,
         MATRIX_T  A       /* out */,
         int       n       /* in  */) {
    int i, j;

    printf("%s\n", prompt);
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++)
            scanf("%f", &A[i][j]);
}  /* Read_matrix */


/*****************************************************************/
/* MATRIX_T Ã© um array bi-dimensional de floats   */
void Serial_matrix_mult(
        MATRIX_T   A   /* in  */,
        MATRIX_T   B   /* in  */,
        MATRIX_T   C   /* out */,
        int        n   /* in  */) {

    int i, j, k;

    void Print_matrix(char* title, MATRIX_T C, int n);

    Print_matrix("Matriz  A = ", A, n);
    Print_matrix("Matriz B = ", B, n);

    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++) {
            C[i][j] = 0.0;
            for (k = 0; k < n; k++)
                C[i][j] = C[i][j] + A[i][k]*B[k][j];
            printf("i = %d, j = %d, c_ij = %f\n", i, j, C[i][j]);
        }
}  /* MultiplicaÃ§Ã£o Serial */


/*****************************************************************/
void Print_matrix(
         char*     title  /* in  */,
         MATRIX_T  C       /* out */,
         int       n       /* in  */) {
    int i, j;

    printf("%s\n", title);
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++)
            printf("%4.1f ", C[i][j]);
        printf("\n");
    }
}  /* Read_matrix */
